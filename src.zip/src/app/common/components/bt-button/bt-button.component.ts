import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'bt-button',
  templateUrl: './bt-button.component.html',
  styleUrls: ['./bt-button.component.scss']
})
export class BtButtonComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
