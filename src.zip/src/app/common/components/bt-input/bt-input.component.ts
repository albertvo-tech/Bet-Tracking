import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'bt-input',
  templateUrl: './bt-input.component.html',
  styleUrls: ['./bt-input.component.scss']
})
export class BtInputComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
