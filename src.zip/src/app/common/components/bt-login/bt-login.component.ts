import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'bt-login',
  templateUrl: './bt-login.component.html',
  styleUrls: ['./bt-login.component.scss']
})
export class BtLoginComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
